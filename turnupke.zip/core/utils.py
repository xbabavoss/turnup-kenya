import base64
import io
import json
import logging
from uuid import uuid4

import qrcode
from django.conf import settings
from django.core.files.base import ContentFile
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

_logger = logging.getLogger(__name__)


def generate_payment_reference(prefix="TXN"):
    return f"{prefix}-{uuid4().hex[:12].upper()}"


def build_qr_payload(ticket):
    payload = {
        "ticket_id": str(ticket.ticket_id),
        "attendee_name": ticket.attendee_name,
        "event_id": ticket.event_id,
    }
    encoded = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode()
    return encoded


def attach_qr(ticket):
    qr_data = ticket.qr_token
    qr = qrcode.QRCode(box_size=8, border=2)
    qr.add_data(qr_data)
    qr.make(fit=True)
    image = qr.make_image(fill_color="white", back_color="#0B0B0F")
    stream = io.BytesIO()
    image.save(stream, "PNG")
    ticket.qr_image.save(f"ticket-{ticket.ticket_id}.png", ContentFile(stream.getvalue()), save=False)


def attach_ticket_pdf(ticket):
    stream = io.BytesIO()
    c = canvas.Canvas(stream, pagesize=letter)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(50, 750, "Turn Up Kenya Ticket")
    c.setFont("Helvetica", 12)
    c.drawString(50, 720, f"Event: {ticket.event.title}")
    c.drawString(50, 700, f"Attendee: {ticket.attendee_name}")
    c.drawString(50, 680, f"Ticket ID: {ticket.ticket_id}")
    c.drawString(50, 660, f"Quantity: {ticket.quantity}")
    c.drawString(50, 640, f"Venue: {ticket.event.venue} - {ticket.event.location}")
    c.drawString(50, 620, f"Date: {ticket.event.starts_at.strftime('%d %b %Y, %H:%M')}")
    c.save()
    ticket.pdf_ticket.save(f"ticket-{ticket.ticket_id}.pdf", ContentFile(stream.getvalue()), save=False)


def send_ticket_email(ticket_id):
    from .models import SiteSettings, Ticket

    ticket = Ticket.objects.select_related("event").get(pk=ticket_id)
    if not ticket.attendee_email:
        _logger.warning("No email on ticket %s", ticket.ticket_id)
        return False

    site = SiteSettings.load()
    context = {"ticket": ticket, "site": site}
    html_body = render_to_string("emails/ticket_confirmation.html", context)
    text_body = (
        f"Your ticket for {ticket.event.title} is confirmed.\n"
        f"Ticket ID: {ticket.ticket_id}\n"
        f"Attendee: {ticket.attendee_name}\n"
        f"Venue: {ticket.event.venue}, {ticket.event.location}\n"
        f"Date: {ticket.event.starts_at}\n"
    )
    email = EmailMultiAlternatives(
        subject=f"Your ticket for {ticket.event.title}",
        body=text_body,
        from_email=settings.DEFAULT_FROM_EMAIL,
        to=[ticket.attendee_email],
    )
    email.attach_alternative(html_body, "text/html")

    if ticket.pdf_ticket:
        with ticket.pdf_ticket.open("rb") as pdf_file:
            email.attach(
                f"ticket-{ticket.ticket_id}.pdf",
                pdf_file.read(),
                "application/pdf",
            )
    if ticket.qr_image:
        with ticket.qr_image.open("rb") as qr_file:
            email.attach(
                f"ticket-{ticket.ticket_id}-qr.png",
                qr_file.read(),
                "image/png",
            )

    try:
        email.send(fail_silently=False)
        _logger.info("Ticket email sent to %s for %s", ticket.attendee_email, ticket.ticket_id)
        return True
    except Exception:
        _logger.exception("Failed to send ticket email to %s", ticket.attendee_email)
        return False
